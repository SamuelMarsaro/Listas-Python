capitalize = "a"
while capitalize != "SAIR" or capitalize != "FIM":
    word = input()
    word = word.replace("4", "A")
    word = word.replace("5", "S")
    word = word.replace("1", "I")
    word = word.replace("3", "E")
    capitalize = word.upper()
    if capitalize == "SAIR" or capitalize == "FIM":
        break
    else:
        print(capitalize)